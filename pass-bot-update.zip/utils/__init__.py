import os
# from utils import create_image, mappings
image_dir = os.path.abspath(os.path.join('assets', 'images'))
